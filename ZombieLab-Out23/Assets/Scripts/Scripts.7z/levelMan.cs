﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class levelMan : MonoBehaviour
{
    public float tmpTime;
 
    int minutes, seconds;
    public Text timerText;
    public GameObject panelTiempoFuera;

    void Start()
    {
        //tmpTime = 3600;
    }

    void Update()
    {
        tmpTime = tmpTime - Time.deltaTime;
        minutes = (int) tmpTime / 60;
        seconds = (int) tmpTime % 60;
        timerText.text = minutes + ":" + seconds;
        
        if (minutes == 0 && seconds <= 0){
            tiempoAgotado();
        }
    }

    void tiempoAgotado()
    {
        panelTiempoFuera.SetActive(true);
    }
}
