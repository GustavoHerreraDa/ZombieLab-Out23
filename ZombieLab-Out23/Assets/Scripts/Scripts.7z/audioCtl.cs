﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class audioCtl : MonoBehaviour
{
    public string url;
    

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            StartCoroutine(AudioPlayer());
        }
    }

    private IEnumerator AudioPlayer()
    {
        WWW music = new WWW(url);
        AudioClip audio = music.GetAudioClip(false, true, AudioType.OGGVORBIS);

        if (audio == null || audio.loadState == AudioDataLoadState.Unloaded)
        {
            Debug.Log("wait for it");
            yield return new WaitForSeconds(0.1f);
        }
        Debug.Log("done!");
        GetComponent<AudioSource>().clip = audio;
        GetComponent<AudioSource>().Play();
    }
}
