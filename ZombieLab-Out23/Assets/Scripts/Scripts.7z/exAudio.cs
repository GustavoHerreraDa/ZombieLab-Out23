﻿using UnityEngine;
using System.Collections;
using System.IO;//path



public class exAudio : MonoBehaviour
{
    public string url;
    public AudioSource source;

    IEnumerator Start()
    {
        string qJson = "sound/" + url+".ogg"; 
        string url1 = Path.Combine(Application.streamingAssetsPath, qJson);
        
        source = GetComponent<AudioSource>();
        using (var www = new WWW(url1))
        {
            yield return www;
            source.clip = www.GetAudioClip();
        }
    }

    void Update()
    {
        if (!source.isPlaying && source.clip.isReadyToPlay)
            source.Play();
    }
}