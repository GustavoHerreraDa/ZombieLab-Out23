﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;

public class enigmaMan : MonoBehaviour
{
    public playerFps pf;
    public GameObject enigma, resultado;
    public Text tituloAcertijo, resultadoAcertijo, resultadoAcertijoCuerpo; 
    [TextArea]
    public Text cuerpoAcertijo;
    
    public levelMan lm;
    public string qJson; //el json que se va a cargar
    public InputField respuestaInput; //el campo de entrada para la respuesta
    private string respuesta, premio;
    private int enigmaActual=0;


    public void Start()
    {
        Invoke("muestraEnigma", 12.0f);
        //carga json y parsea...
        qJson = "barbanegra.json";
        string fileName = Path.Combine(Application.streamingAssetsPath, qJson);
        //LoadJson(fileName);
        StartCoroutine(GetRequest(fileName));
    }

    public void muestraEnigma()
    {
        resultado.gameObject.SetActive(false);//esto es en caso de repetición..
        Debug.Log("mostrando el enigma");
        //quita control de player para que noestorbe
        //pf.gameObject.SetActive(false);
        pf.canMove = false; //desativa script
        //muestra enigma
        enigma.gameObject.SetActive(true);
        //
    }

    public void checaResultadoEnigma()
    {
        //revisa si la respuesta es correcta, en caso de que lo sea regresa ctl. Falta implementar...
        //pf.gameObject.SetActive(true);
        Debug.Log(respuestaInput.text);
        pf.canMove = true; //desativa script
        resultado.gameObject.SetActive(true);
        
        resultadoAcertijo.gameObject.SetActive(true);
        if (respuestaInput.text == respuesta){
            resultadoAcertijo.text = "¡Muy bien!";
            resultadoAcertijoCuerpo.text = "Has ganado " +premio;
            enigmaActual += 1;//si todavía hay engimas por resolver, en caso contrario regresarlo.
        }
        else
        {
            resultadoAcertijo.text = "Incorrecto. ";
            resultadoAcertijoCuerpo.text ="Vuelve a intentar";
            Invoke("muestraEnigma", 2.0f);
            
        }


    }
    
    IEnumerator GetRequest(string uri)
    {
        using (UnityWebRequest webRequest = UnityWebRequest.Get(uri))
        {
            // Request and wait for the desired page.
            yield return webRequest.SendWebRequest();
            Debug.Log("se obtuvo: " + webRequest +  webRequest.downloadHandler.text);
            string json = webRequest.downloadHandler.text;
            ListEnigmas q = JsonUtility.FromJson<ListEnigmas>(json);
            respuesta = q.Enigmas[enigmaActual].Clave;
            cuerpoAcertijo.text = q.Enigmas[enigmaActual].Acertijo;
            tituloAcertijo.text = q.Enigmas[enigmaActual].Titulo;
            premio = q.Enigmas[enigmaActual].Premio;
        }
    }
    
    /// <summary>
    ///funcion dedicada a carga el json, parsearlo y tenerlo lsito para mostrar
    /// </summary>
    /// <param name="fileName"></param>
    public void LoadJson(string fileName)
    {
        using (StreamReader r = new StreamReader(fileName))
        {
            string json = r.ReadToEnd();
            ListEnigmas q = JsonUtility.FromJson<ListEnigmas>(json);

            respuesta = q.Enigmas[enigmaActual].Clave;
            cuerpoAcertijo.text = q.Enigmas[enigmaActual].Acertijo;
            tituloAcertijo.text = q.Enigmas[enigmaActual].Titulo;
            
            for(int i=0; i<q.Enigmas.Length; i++)
            {
                //Debug.Log(i + q.Quests[i].Name + " "+q.Quests[i].Reward) ;
                Debug.Log(q.Enigmas[i].Titulo);
                Debug.Log(q.Enigmas[i].Acertijo);
                Debug.Log(q.Enigmas[i].Premio);
                Debug.Log(q.Enigmas[i].Valor);
                Debug.Log(q.Enigmas[i].TipoAcertijo);
            }
            
        }
    }


}


[Serializable]
public class ListEnigmas  {
    public Enigmas[] Enigmas;
}

[Serializable]
public class Enigmas
{
    public string Titulo;
    public string Acertijo;
    public string Premio;
    public string Clave;
    public int Valor;
    public int TipoAcertijo;
}

