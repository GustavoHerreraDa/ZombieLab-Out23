﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;


public class audioMan : MonoBehaviour
{
    public string url;
    public AudioSource source;
    private AudioSource audiosrc;

    void Start()
    {
        //StartCoroutine(GetAudioClip());
        StartCoroutine(StartA());
        audiosrc.Play();    
    }
    
    // Use this for initialization
    IEnumerator StartA()
    {
        //url = "File://" + Application.dataPath + "/StreamingAssets/sound/" + url + ".ogg";
        string qJson = "sound/" + url+".ogg"; 
        string url1 = Path.Combine(Application.streamingAssetsPath, qJson);
        //Debug.Log(url1);
        audiosrc = Instantiate (source);
        using (var www = new WWW(url1))
        {
            yield return www;
            audiosrc.clip = www.GetAudioClip ();
        }
        
        Debug.Log("lets play some music");
        
    }
    
    
    
    IEnumerator GetAudioClip()
    {
        string qJson = "sound/" + url+".ogg"; 
        string url1 = Path.Combine(Application.streamingAssetsPath, qJson);
        using (UnityWebRequest www = UnityWebRequestMultimedia.GetAudioClip(url1, AudioType.OGGVORBIS))
        {
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.ConnectionError)
            {
                Debug.Log(www.error);
            }
            else
            {
                audiosrc.clip = DownloadHandlerAudioClip.GetContent(www);
                audiosrc.Play();
            }
            
        }
    }
}
